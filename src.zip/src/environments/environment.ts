export const environment = {
  production: false,
  apiUrl: 'http://localhost:5000/api',
  useMockData: false // Disable mock data to use real API
};