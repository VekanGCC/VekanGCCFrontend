export const environment = {
  production: true,
  apiUrl: 'http://localhost:5000/api',
  useMockData: false // Disable mock data to use real API
};