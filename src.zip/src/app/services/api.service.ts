import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { delay, map, catchError, tap, retry } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { ApiResponse } from '../models/api-response.model';
import { AdminSkill } from '../models/admin.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = environment.apiUrl;
  private useMockData = environment.useMockData;

  constructor(private http: HttpClient) {}

  private getHttpOptions() {
    const token = sessionStorage.getItem('token');
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : ''
      })
    };
  }

  private handleError(error: HttpErrorResponse) {
    if (error.status === 401) {
      // Token expired or invalid
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('user');
      window.location.href = '/login';
    }
    return throwError(() => error);
  }

  // Generic GET request
  get<T>(endpoint: string): Observable<T> {
    return this.http.get<T>(`${this.apiUrl}${endpoint}`, this.getHttpOptions())
      .pipe(
        retry(1),
        catchError(this.handleError)
      );
  }

  // Generic POST request
  post<T>(endpoint: string, data: any): Observable<T> {
    return this.http.post<T>(`${this.apiUrl}${endpoint}`, data, this.getHttpOptions())
      .pipe(
        retry(1),
        catchError(this.handleError)
      );
  }

  // Generic PUT request
  put<T>(endpoint: string, data: any): Observable<T> {
    return this.http.put<T>(`${this.apiUrl}${endpoint}`, data, this.getHttpOptions())
      .pipe(
        retry(1),
        catchError(this.handleError)
      );
  }

  // Generic DELETE request
  delete<T>(endpoint: string): Observable<T> {
    return this.http.delete<T>(`${this.apiUrl}${endpoint}`, this.getHttpOptions())
      .pipe(
        retry(1),
        catchError(this.handleError)
      );
  }

  // User APIs
  getUsers(): Observable<any> {
    console.log('👥 API: Fetching users...');
    return this.get('/users');
  }

  // Resource APIs
  getResources(): Observable<any> {
    console.log('🧑‍💼 API: Fetching resources from:', `${this.apiUrl}/resources`);
    return this.get('/resources').pipe(
      tap(response => console.log('🧑‍💼 API: Resources response:', response)),
      catchError(error => {
        console.error('❌ API: Error fetching resources:', error);
        return throwError(() => error);
      })
    );
  }

  // Requirement APIs
  getRequirements(): Observable<any> {
    console.log('📋 API: Fetching requirements...');
    return this.get('/requirements');
  }

  // Application APIs
  getApplications(): Observable<any> {
    console.log('📊 API: Fetching applications...');
    return this.get('/applications');
  }

  // Generic Skills (Admin Skills)
  getAdminSkills(): Observable<ApiResponse<AdminSkill[]>> {
    console.log('🔧 API: Fetching admin skills...');
    return this.get<ApiResponse<AdminSkill[]>>('/admin/skills');
  }

  // Get active skills for vendors
  getActiveSkills(): Observable<ApiResponse<AdminSkill[]>> {
    console.log('🔧 API: Fetching active skills...');
    return this.get<ApiResponse<AdminSkill[]>>('/skills/active');
  }

  // Vendor Niche Skills
  getVendorSkills(): Observable<any> {
    console.log('🎯 API: Fetching vendor niche skills...');
    return this.get('/vendor/niche-skills');
  }

  // Admin APIs
  getAdminDashboard(): Observable<any> {
    console.log('📊 API: Fetching admin dashboard data...');
    return this.get('/admin/stats');
  }

  approveEntity(approvalId: string, notes?: string): Observable<any> {
    console.log('✅ API: Approving entity:', approvalId);
    return this.post('/admin/approvals/approve', { approvalId, notes });
  }

  rejectEntity(approvalId: string, notes: string): Observable<any> {
    console.log('❌ API: Rejecting entity:', approvalId);
    return this.post('/admin/approvals/reject', { approvalId, notes });
  }

  approveUser(userId: string, notes?: string): Observable<any> {
    console.log('✅ API: Approving user:', userId);
    return this.post('/admin/users/approve', { userId, notes });
  }

  rejectUser(userId: string, notes: string): Observable<any> {
    console.log('❌ API: Rejecting user:', userId);
    return this.post('/admin/users/reject', { userId, notes });
  }

  getPlatformStats(): Observable<any> {
    console.log('📈 API: Fetching platform statistics...');
    return this.get('/admin/stats');
  }

  // Authentication APIs
  login(credentials: { email: string; password: string }): Observable<any> {
    console.log('🔐 API: Login attempt for:', credentials.email);
    
    return this.http.post(`${this.apiUrl}/auth/login`, credentials, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }).pipe(
      catchError(error => {
        console.error('❌ API: Login error:', error);
        return throwError(() => error);
      })
    );
  }

  verifyToken(token: string): Observable<any> {
    console.log('🔒 API: Verifying token');
    
    if (this.useMockData) {
      // For mock data, we'll simulate token verification
      return of({ success: true }).pipe(delay(300));
    } else {
      return this.http.get(`${this.apiUrl}/auth/verify`, {
        headers: new HttpHeaders({
          'Authorization': `Bearer ${token}`
        })
      }).pipe(
        catchError(error => {
          console.error('❌ API: Token verification error:', error);
          return throwError(() => error);
        })
      );
    }
  }

  logout(): Observable<any> {
    try {
      return this.http.post(`${this.apiUrl}/auth/logout`, {}, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Logout error:', error);
          return of({ success: true });
        })
      );
    } catch (error) {
      console.error('❌ API: Logout error:', error);
      return of({ success: true });
    }
  }

  createResource(resource: any): Observable<any> {
    console.log('➕ API: Creating resource:', resource.name);
    
    if (this.useMockData) {
      return this.http.get<any>('/assets/mock-data/resources.json').pipe(
        delay(500),
        map(resources => {
          const newResource = {
            ...resource,
            id: Date.now().toString(),
            createdAt: new Date().toISOString().split('T')[0]
          };
          console.log('✅ API: Resource created:', newResource);
          return { success: true, data: newResource };
        }),
        catchError(error => {
          console.error('❌ API: Create resource error:', error);
          return of({ success: false, message: 'Error creating resource' });
        })
      );
    } else {
      return this.http.post(`${this.apiUrl}/resources`, resource, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Create resource error:', error);
          return of({ success: false, message: 'Error creating resource' });
        })
      );
    }
  }

  updateResource(id: string, resource: any): Observable<any> {
    console.log('📝 API: Updating resource:', id);
    
    if (this.useMockData) {
      return of({ success: true, data: { ...resource, id } }).pipe(delay(500));
    } else {
      return this.http.put(`${this.apiUrl}/resources/${id}`, resource, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Update resource error:', error);
          return of({ success: false, message: 'Error updating resource' });
        })
      );
    }
  }

  deleteResource(id: string): Observable<any> {
    console.log('🗑️ API: Deleting resource:', id);
    
    if (this.useMockData) {
      return of({ success: true }).pipe(delay(500));
    } else {
      return this.http.delete(`${this.apiUrl}/resources/${id}`, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Delete resource error:', error);
          return of({ success: false, message: 'Error deleting resource' });
        })
      );
    }
  }

  createRequirement(requirement: any): Observable<any> {
    console.log('➕ API: Creating requirement:', requirement.title);
    
    if (this.useMockData) {
      return this.http.get<any>('/assets/mock-data/requirements.json').pipe(
        delay(500),
        map(requirements => {
          const newRequirement = {
            ...requirement,
            id: Date.now().toString(),
            createdAt: new Date().toISOString().split('T')[0]
          };
          console.log('✅ API: Requirement created:', newRequirement);
          return { success: true, data: newRequirement };
        }),
        catchError(error => {
          console.error('❌ API: Create requirement error:', error);
          return of({ success: false, message: 'Error creating requirement' });
        })
      );
    } else {
      return this.http.post(`${this.apiUrl}/requirements`, requirement, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Create requirement error:', error);
          return of({ success: false, message: 'Error creating requirement' });
        })
      );
    }
  }

  updateRequirement(id: string, requirement: any): Observable<any> {
    console.log('📝 API: Updating requirement:', id);
    
    if (this.useMockData) {
      return of({ success: true, data: { ...requirement, id } }).pipe(delay(500));
    } else {
      return this.http.put(`${this.apiUrl}/requirements/${id}`, requirement, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Update requirement error:', error);
          return of({ success: false, message: 'Error updating requirement' });
        })
      );
    }
  }

  updateRequirementStatus(id: string, status: string): Observable<any> {
    console.log('🔄 API: Updating requirement status:', id, status);
    
    if (this.useMockData) {
      return of({ success: true, data: { id, status } }).pipe(delay(500));
    } else {
      return this.http.patch(`${this.apiUrl}/requirements/${id}/status`, { status }, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Update requirement status error:', error);
          return of({ success: false, message: 'Error updating requirement status' });
        })
      );
    }
  }

  createApplication(application: any): Observable<any> {
    console.log('➕ API: Creating application...');
    
    if (this.useMockData) {
      return this.http.get<any>('/assets/mock-data/applications.json').pipe(
        delay(500),
        map(applications => {
          const newApplication = {
            ...application,
            id: Date.now().toString(),
            createdAt: new Date().toISOString().split('T')[0],
            updatedAt: new Date().toISOString().split('T')[0]
          };
          console.log('✅ API: Application created:', newApplication);
          return { success: true, data: newApplication };
        }),
        catchError(error => {
          console.error('❌ API: Create application error:', error);
          return of({ success: false, message: 'Error creating application' });
        })
      );
    } else {
      return this.http.post(`${this.apiUrl}/applications`, application, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Create application error:', error);
          return of({ success: false, message: 'Error creating application' });
        })
      );
    }
  }

  updateApplicationStatus(id: string, status: string, notes?: string): Observable<any> {
    console.log('🔄 API: Updating application status:', id, status);
    
    if (this.useMockData) {
      return of({ 
        success: true, 
        data: { 
          id, 
          status, 
          notes,
          updatedAt: new Date().toISOString().split('T')[0]
        } 
      }).pipe(delay(500));
    } else {
      return this.http.patch(`${this.apiUrl}/applications/${id}/status`, { status, notes }, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Update application status error:', error);
          return of({ success: false, message: 'Error updating application status' });
        })
      );
    }
  }

  // Vendor User APIs
  getVendorUsers(): Observable<any> {
    console.log('👥 API: Fetching vendor users...');
    return this.get('/vendor-users');
  }

  createVendorUser(user: any): Observable<any> {
    console.log('➕ API: Creating vendor user:', user.name);
    
    if (this.useMockData) {
      return this.http.get<any>('/assets/mock-data/vendor-users.json').pipe(
        delay(500),
        map(users => {
          const newUser = {
            ...user,
            id: Date.now().toString(),
            createdAt: new Date().toISOString().split('T')[0]
          };
          console.log('✅ API: Vendor user created:', newUser);
          return { success: true, data: newUser };
        }),
        catchError(error => {
          console.error('❌ API: Create vendor user error:', error);
          return of({ success: false, message: 'Error creating vendor user' });
        })
      );
    } else {
      return this.http.post(`${this.apiUrl}/vendor-users`, user, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Create vendor user error:', error);
          return of({ success: false, message: 'Error creating vendor user' });
        })
      );
    }
  }

  updateVendorUserStatus(id: string, status: string): Observable<any> {
    console.log('🔄 API: Updating vendor user status:', id, status);
    
    if (this.useMockData) {
      return of({ success: true, data: { id, status } }).pipe(delay(500));
    } else {
      return this.http.patch(`${this.apiUrl}/vendor-users/${id}/status`, { status }, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Update vendor user status error:', error);
          return of({ success: false, message: 'Error updating vendor user status' });
        })
      );
    }
  }

  // Generic Skills (Admin Skills)
  createAdminSkill(skill: any): Observable<any> {
    console.log('➕ API: Creating admin skill:', skill.name);
    
    if (this.useMockData) {
      return this.post('/admin/skills', skill);
    } else {
      return this.http.post(`${this.apiUrl}/skills`, skill, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Create admin skill error:', error);
          return of({ success: false, message: 'Error creating admin skill' });
        })
      );
    }
  }

  updateAdminSkill(id: string, updates: any): Observable<any> {
    console.log('📝 API: Updating admin skill:', id);
    
    if (this.useMockData) {
      return this.post('/admin/skills', updates);
    } else {
      return this.http.put(`${this.apiUrl}/skills/${id}`, updates, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Update admin skill error:', error);
          return of({ success: false, message: 'Error updating admin skill' });
        })
      );
    }
  }

  deleteAdminSkill(id: string): Observable<any> {
    console.log('🗑️ API: Deleting admin skill:', id);
    
    if (this.useMockData) {
      return this.delete('/admin/skills');
    } else {
      return this.http.delete(`${this.apiUrl}/skills/${id}`, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Delete admin skill error:', error);
          return of({ success: false, message: 'Error deleting admin skill' });
        })
      );
    }
  }

  // Vendor Niche Skills
  createVendorSkill(skill: any): Observable<any> {
    console.log('➕ API: Creating vendor niche skill:', skill.skillName);
    
    if (this.useMockData) {
      return this.post('/vendor-skills', skill);
    } else {
      return this.http.post(`${this.apiUrl}/vendor/niche-skills`, skill, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Create vendor niche skill error:', error);
          return of({ success: false, message: 'Error creating vendor niche skill' });
        })
      );
    }
  }

  updateVendorSkillStatus(id: string, status: string, reviewNotes?: string): Observable<any> {
    console.log('🔄 API: Updating vendor niche skill status:', id, status);
    
    if (this.useMockData) {
      return this.post('/vendor-skills', { status, reviewNotes });
    } else {
      return this.http.patch(`${this.apiUrl}/vendor/niche-skills/${id}/status`, { status, reviewNotes }, this.getHttpOptions()).pipe(
        catchError(error => {
          console.error('❌ API: Update vendor niche skill status error:', error);
          return of({ success: false, message: 'Error updating vendor niche skill status' });
        })
      );
    }
  }

  getPendingApprovals(): Observable<any> {
    console.log('⏳ API: Fetching pending approvals...');
    return this.get('/admin/approvals');
  }

  getAllTransactions(): Observable<any> {
    console.log('💰 API: Fetching all transactions...');
    return this.get('/admin/transactions');
  }

  getAdminUsers(): Observable<any> {
    console.log('👥 API: Fetching admin users...');
    return this.get('/admin/users');
  }

  createAdminUser(user: any): Observable<any> {
    console.log('➕ API: Creating admin user:', user.email);
    return this.post('/admin/users', user);
  }
}