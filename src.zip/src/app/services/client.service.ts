import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ClientService {
  private apiUrl = `${environment.apiUrl}/clients`;

  constructor(private http: HttpClient) {}

  // Get client profile
  getProfile(): Observable<any> {
    return this.http.get(`${this.apiUrl}/profile`);
  }

  // Update client profile
  updateProfile(data: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/profile`, data);
  }

  // Get client requirements
  getRequirements(): Observable<any> {
    return this.http.get(`${this.apiUrl}/requirements`);
  }

  // Create new requirement
  createRequirement(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/requirements`, data);
  }

  // Update requirement
  updateRequirement(id: string, data: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/requirements/${id}`, data);
  }

  // Delete requirement
  deleteRequirement(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/requirements/${id}`);
  }

  // Get client applications
  getApplications(): Observable<any> {
    return this.http.get(`${this.apiUrl}/applications`);
  }

  // Get client analytics
  getAnalytics(): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics`);
  }
} 