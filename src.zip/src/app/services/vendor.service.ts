import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VendorService {
  private apiUrl = `${environment.apiUrl}/vendors`;

  constructor(private http: HttpClient) {}

  // Get vendor profile
  getProfile(): Observable<any> {
    return this.http.get(`${this.apiUrl}/profile`);
  }

  // Update vendor profile
  updateProfile(data: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/profile`, data);
  }

  // Get vendor resources
  getResources(): Observable<any> {
    return this.http.get(`${this.apiUrl}/resources`);
  }

  // Create new resource
  createResource(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/resources`, data);
  }

  // Update resource
  updateResource(id: string, data: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/resources/${id}`, data);
  }

  // Delete resource
  deleteResource(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/resources/${id}`);
  }

  // Get vendor applications
  getApplications(): Observable<any> {
    return this.http.get(`${this.apiUrl}/applications`);
  }

  // Get vendor analytics
  getAnalytics(): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics`);
  }

  // Get vendor skills
  getSkills(): Observable<any> {
    return this.http.get(`${this.apiUrl}/skills`);
  }

  // Add vendor skill
  addSkill(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/skills`, data);
  }

  // Remove vendor skill
  removeSkill(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/skills/${id}`);
  }
} 