import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, firstValueFrom } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user.model';
import { ApiService } from './api.service';

interface ApiResponse {
  success: boolean;
  message: string;
  token?: string;
  refreshToken?: string;
  data?: User;
}

interface UsersResponse {
  success: boolean;
  data: User[];
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  private isLoadingSubject = new BehaviorSubject<boolean>(false);

  // Expose observables
  public user$ = this.currentUserSubject.asObservable();
  public currentUser$ = this.user$; // Alias for backward compatibility
  public isLoading$ = this.isLoadingSubject.asObservable();

  constructor(private apiService: ApiService) {
    this.initializeAuth();
  }

  private async initializeAuth(): Promise<void> {
    const token = sessionStorage.getItem('token');
    const user = sessionStorage.getItem('user');
    
    if (token && user) {
      try {
        const parsedUser = JSON.parse(user);
        // Verify that the user data is valid
        if (parsedUser && parsedUser._id && parsedUser.email) {
          // Verify token with backend
          const response = await firstValueFrom(this.apiService.verifyToken(token));
          if (response.success) {
            console.log('AuthService: Token verified, initializing user:', parsedUser);
            this.currentUserSubject.next(parsedUser);
          } else {
            console.log('AuthService: Token verification failed, clearing auth state');
            this.clearAuthState();
          }
        } else {
          console.log('AuthService: Invalid user data, clearing auth state');
          this.clearAuthState();
        }
      } catch (error) {
        console.error('AuthService: Error during initialization:', error);
        this.clearAuthState();
      }
    } else {
      this.clearAuthState();
    }
  }

  private clearAuthState(): void {
    console.log('AuthService: Clearing authentication state');
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('refreshToken');
    this.currentUserSubject.next(null);
  }

  async login(email: string, password: string): Promise<boolean> {
    console.log('AuthService: Login attempt with:', { email });
    this.isLoadingSubject.next(true);
    
    try {
      const response = await firstValueFrom(
        this.apiService.post<ApiResponse>('/auth/login', { email, password })
      );
      console.log('AuthService: Login response:', response);

      if (response.token && response.data) {
        console.log('AuthService: Login successful, storing user data and tokens');
        // Store tokens
        sessionStorage.setItem('token', response.token);
        if (response.refreshToken) {
          sessionStorage.setItem('refreshToken', response.refreshToken);
        }
        
        // Store user data
        sessionStorage.setItem('user', JSON.stringify(response.data));
        this.currentUserSubject.next(response.data);
        return true;
      }
      return false;
    } catch (error) {
      console.error('AuthService: Login error:', error);
      this.clearAuthState();
      return false;
    } finally {
      this.isLoadingSubject.next(false);
    }
  }

  async logout(): Promise<void> {
    console.log('AuthService: Logging out');
    try {
      await firstValueFrom(this.apiService.logout());
    } catch (error) {
      console.error('AuthService: Logout error:', error);
    } finally {
      this.clearAuthState();
    }
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  // Alias for backward compatibility
  get currentUser(): User | null {
    return this.getCurrentUser();
  }

  isAuthenticated(): boolean {
    const token = sessionStorage.getItem('token');
    const user = this.currentUserSubject.value;
    return !!token && !!user && !!user._id;
  }

  // Get users (for admin)
  getUsers(): Observable<User[]> {
    return this.apiService.get<UsersResponse>('/users').pipe(
      map(response => response.success ? response.data : [])
    );
  }
}