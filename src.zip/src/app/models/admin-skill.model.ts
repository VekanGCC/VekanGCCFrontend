export interface AdminSkill {
  id: string;
  name: string;
  category: string;
  description: string;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
} 