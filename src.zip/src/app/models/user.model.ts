export interface User {
  _id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  userType: 'vendor' | 'client' | 'admin';
  isActive: boolean;
  isEmailVerified: boolean;
  isApproved: boolean;
  approvalStatus: 'pending' | 'approved' | 'rejected';
  companyName: string;
  contactPerson: string;
  mobileNumber: string;
  gstNumber: string;
  serviceType: string;
  numberOfResources?: number;
  numberOfRequirements?: number;
  paymentTerms?: string;
  businessInfo?: {
    companyName: string;
    businessType?: string;
    registrationNumber?: string;
    taxId?: string;
  };
  createdAt: string;
  updatedAt: string;
  rejectionReason?: string;
}

export interface UserAddress {
  _id: string;
  userId: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  country: string;
  pinCode: string;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface UserBankDetails {
  _id: string;
  userId: string;
  bankAccountNumber: string;
  accountType: string;
  ifscCode: string;
  bankName: string;
  branchName: string;
  bankCity: string;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface UserStatutoryCompliance {
  _id: string;
  userId: string;
  panNumber: string;
  registeredUnderESI: boolean;
  esiRegistrationNumber?: string;
  registeredUnderPF: boolean;
  pfRegistrationNumber?: string;
  registeredUnderMSMED: boolean;
  compliesWithStatutoryRequirements: boolean;
  hasCloseRelativesInCompany: boolean;
  hasAdequateSafetyStandards: boolean;
  hasOngoingLitigation: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface LoginResponse {
  success: boolean;
  token: string;
  user: User;
}

export interface ApiResponse {
  success: boolean;
  message?: string;
  data?: any;
  error?: string;
}