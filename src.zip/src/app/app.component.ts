import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterOutlet } from '@angular/router';
import { AuthService } from './services/auth.service';
import { User } from './models/user.model';
import { LucideAngularModule } from 'lucide-angular';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, LucideAngularModule],
  template: '<router-outlet></router-outlet>'
})
export class AppComponent implements OnInit {
  constructor(
    public authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    // Subscribe to user changes
    this.authService.user$.subscribe(user => {
      console.log('App: User state changed:', user);
      
      if (user && this.authService.isAuthenticated()) {
        console.log('App: User is authenticated, userType:', user.userType);
        // Redirect to appropriate dashboard if on public routes
        const publicRoutes = ['/', '/login', '/signup'];
        if (publicRoutes.includes(this.router.url)) {
          this.navigateBasedOnRole(user);
        }
      } else {
        console.log('App: No user logged in or not authenticated');
        // Only navigate to landing page if trying to access protected routes
        const publicRoutes = ['/', '/login', '/signup'];
        if (!publicRoutes.includes(this.router.url)) {
          this.router.navigate(['/login']);
        }
      }
    });
  }

  private navigateBasedOnRole(user: User): void {
    console.log('App: Navigating based on userType:', user.userType);
    
    switch (user.userType) {
      case 'admin':
        this.router.navigate(['/admin-dashboard']);
        break;
      case 'vendor':
        this.router.navigate(['/vendor-dashboard']);
        break;
      case 'client':
        this.router.navigate(['/client-dashboard']);
        break;
      default:
        this.router.navigate(['/']);
    }
  }
}