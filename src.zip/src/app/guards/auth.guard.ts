import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable, map, take } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  canActivate(): Observable<boolean> {
    console.log('AuthGuard: Checking authentication');
    return this.authService.user$.pipe(
      take(1),
      map(user => {
        console.log('AuthGuard: User state:', user);
        if (user) {
          console.log('AuthGuard: User is authenticated');
          return true;
        }
        console.log('AuthGuard: User is not authenticated, redirecting to login');
        this.router.navigate(['/login']);
        return false;
      })
    );
  }
}