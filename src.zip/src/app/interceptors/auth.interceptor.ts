import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private isRedirecting = false;

  constructor(private router: Router) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // Skip all handling for logout requests
    if (request.url.includes('/auth/logout')) {
      return next.handle(request);
    }

    // Get the auth token from localStorage
    const authToken = localStorage.getItem('authToken');
    
    // Skip adding token for login and public endpoints
    if (request.url.includes('/auth/login') || 
        request.url.includes('/assets/') || 
        !authToken) {
      return next.handle(request);
    }

    // Clone the request and add the authorization header
    const authReq = request.clone({
      headers: request.headers.set('Authorization', `Bearer ${authToken}`)
    });

    // Handle the request and catch any authentication errors
    return next.handle(authReq).pipe(
      catchError((error: HttpErrorResponse) => {
        if (error.status === 401 && !this.isRedirecting) {
          // If we get a 401 Unauthorized response, the token is invalid or expired
          console.log('🔒 Auth token expired or invalid, redirecting to login');
          this.isRedirecting = true;
          localStorage.removeItem('authToken');
          localStorage.removeItem('user');
          
          // Only redirect if we're not already on the login page
          if (!this.router.url.includes('/login')) {
            this.router.navigate(['/login']).then(() => {
              this.isRedirecting = false;
            });
          } else {
            this.isRedirecting = false;
          }
        }
        return throwError(error);
      })
    );
  }
}