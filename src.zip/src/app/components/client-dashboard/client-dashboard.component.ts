import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { AppService } from '../../services/app.service';
import { User } from '../../models/user.model';
import { Resource } from '../../models/resource.model';
import { Requirement } from '../../models/requirement.model';
import { Application } from '../../models/application.model';
import { LayoutComponent } from '../layout/layout.component';
import { LucideAngularModule } from 'lucide-angular';
import { RequirementModalComponent } from '../modals/requirement-modal/requirement-modal.component';
import { ApplyResourceModalComponent } from '../modals/apply-resource-modal/apply-resource-modal.component';
import { firstValueFrom } from 'rxjs';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-client-dashboard',
  standalone: true,
  imports: [
    CommonModule, 
    LayoutComponent, 
    LucideAngularModule,
    RequirementModalComponent,
    ApplyResourceModalComponent
  ],
  templateUrl: './client-dashboard.component.html',
  styleUrls: ['./client-dashboard.component.css']
})
export class ClientDashboardComponent implements OnInit {
  currentUser: User | null = null;
  isLoading = false;
  requirements: Requirement[] = [];
  applications: Application[] = [];
  resources: Resource[] = [];
  clientRequirements: Requirement[] = [];
  clientApplications: Application[] = [];
  activeTab = 'overview';
  showRequirementModal = false;
  showApplyModal = false;
  showCloseRequirementModal = false;
  selectedResourceId = '';
  requirementToClose: Requirement | null = null;
  stats = [
    { 
      title: 'Requirements', 
      value: 0,
      icon: 'briefcase',
      bg: 'bg-blue-50',
      color: 'text-blue-600'
    },
    { 
      title: 'Resources', 
      value: 0,
      icon: 'users',
      bg: 'bg-green-50',
      color: 'text-green-600'
    },
    { 
      title: 'Active Applications', 
      value: 0,
      icon: 'trending-up',
      bg: 'bg-purple-50',
      color: 'text-purple-600'
    },
    { 
      title: 'Onboarded Resources', 
      value: 0,
      icon: 'check-circle',
      bg: 'bg-yellow-50',
      color: 'text-yellow-600'
    }
  ];

  constructor(
    private authService: AuthService,
    private appService: AppService,
    private router: Router,
    private apiService: ApiService
  ) {}

  ngOnInit() {
    // Subscribe to user changes
    this.authService.user$.subscribe(user => {
      console.log('Client Dashboard: User state changed:', user);
      this.currentUser = user;
      
      if (user) {
        console.log('Client Dashboard: User type:', user.userType);
        
        // Check if user is client
        if (user.userType !== 'client') {
          console.log('Client Dashboard: User is not client, redirecting...');
          this.router.navigate(['/']);
          return;
        }
        
        // Load client data
        this.loadClientData();
      } else {
        console.log('Client Dashboard: No user logged in, redirecting...');
        this.router.navigate(['/login']);
      }
    });

    // Subscribe to loading state
    this.authService.isLoading$.subscribe(isLoading => {
      this.isLoading = isLoading;
    });

    // Subscribe to resources
    this.appService.resources$.subscribe(resources => {
      console.log('Client Dashboard: Received resources:', resources);
      this.resources = resources;
      this.loadClientData();
    });

    // Subscribe to requirements
    this.appService.requirements$.subscribe(requirements => {
      this.requirements = requirements;
      this.loadClientData();
    });

    // Subscribe to applications
    this.appService.applications$.subscribe(applications => {
      this.applications = applications;
      this.loadClientData();
    });
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
    if (tab === 'resources') {
      console.log('Client Dashboard: Switching to resources tab, reloading resources...');
      this.loadResources();
    }
  }

  private async loadResources(): Promise<void> {
    try {
      console.log('Client Dashboard: Manually loading resources...');
      const response = await firstValueFrom(this.apiService.getResources());
      console.log('Client Dashboard: Resources response:', response);
      if (response.success && response.data) {
        this.resources = response.data.filter((item: any) => item != null);
        this.loadClientData();
      }
    } catch (error) {
      console.error('Client Dashboard: Error loading resources:', error);
    }
  }

  getResourceName(resourceId: string): string {
    const resource = this.resources.find(r => r._id === resourceId);
    return resource ? resource.name : 'Unknown Resource';
  }

  getRequirementTitle(requirementId: string): string {
    const requirement = this.requirements.find(r => r._id === requirementId);
    return requirement ? requirement.title : 'Unknown Requirement';
  }

  getStatusBadge(status: string): { color: string, icon: string } {
    switch (status) {
      case 'pending':
        return { color: 'bg-yellow-100 text-yellow-800', icon: 'clock' };
      case 'approved':
        return { color: 'bg-green-100 text-green-800', icon: 'check-circle' };
      case 'rejected':
        return { color: 'bg-red-100 text-red-800', icon: 'x-circle' };
      case 'onboarded':
        return { color: 'bg-blue-100 text-blue-800', icon: 'user-check' };
      default:
        return { color: 'bg-gray-100 text-gray-800', icon: 'help-circle' };
    }
  }

  formatStatus(status: string): string {
    return status.charAt(0).toUpperCase() + status.slice(1);
  }

  closeApplyModal(): void {
    this.showApplyModal = false;
    this.selectedResourceId = '';
  }

  closeCloseRequirementModal(): void {
    this.showCloseRequirementModal = false;
    this.requirementToClose = null;
  }

  confirmCloseRequirement(): void {
    if (this.requirementToClose) {
      // Add your requirement closing logic here
      this.closeCloseRequirementModal();
    }
  }

  private loadClientData(): void {
    if (!this.currentUser) {
      this.clientRequirements = [];
      this.clientApplications = [];
      this.stats.forEach(stat => stat.value = 0);
      return;
    }

    const userId = this.currentUser._id;

    // Load client-specific data
    console.log('Client Dashboard: Loading client data...');
    
    // Filter requirements and applications
    this.clientRequirements = this.requirements.filter(r => r.clientId === userId);
    this.clientApplications = this.applications.filter(a => a.clientId === userId);
    
    // Update stats
    this.stats[0].value = this.clientRequirements.length;
    this.stats[1].value = this.resources.length;
    this.stats[2].value = this.clientApplications.filter(a => !['rejected', 'onboarded'].includes(a.status)).length;
    this.stats[3].value = this.clientApplications.filter(a => a.status === 'onboarded').length;
  }

  getStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'open':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'closed':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  getStatusIcon(status: string): string {
    switch (status.toLowerCase()) {
      case 'open':
        return 'check-circle';
      case 'in-progress':
        return 'clock';
      case 'closed':
        return 'x-circle';
      default:
        return 'help-circle';
    }
  }

  // Add trackById function
  trackById(index: number, item: any): string {
    return item._id;
  }

  // Add requirement management functions
  editRequirement(req: any): void {
    // TODO: Implement edit functionality
    console.log('Edit requirement:', req);
  }

  deleteRequirement(id: string): void {
    // TODO: Implement delete functionality
    console.log('Delete requirement:', id);
  }
}