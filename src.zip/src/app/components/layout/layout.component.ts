import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user.model';
import { LucideAngularModule } from 'lucide-angular';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="min-h-screen bg-gray-100">
      <nav class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between h-16">
            <div class="flex">
              <div class="flex-shrink-0 flex items-center">
                <a routerLink="/" class="text-xl font-bold text-blue-600">TalentBridge</a>
              </div>
            </div>
            <div class="flex items-center">
              <div *ngIf="currentUser$ | async as user" class="ml-3 relative">
                <div class="flex items-center space-x-4">
                  <p class="text-sm font-medium text-gray-700">{{user.firstName}} {{user.lastName}}</p>
                  <p class="text-xs text-gray-500 capitalize">{{user.userType}}</p>
                  <button
                    (click)="logout()"
                    class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    <lucide-icon name="log-out" class="w-4 h-4 mr-1"></lucide-icon>
                    Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main class="py-10">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <ng-content></ng-content>
        </div>
      </main>
    </div>
  `
})
export class LayoutComponent {
  currentUser$ = this.authService.user$;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}