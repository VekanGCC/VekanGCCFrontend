import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { AdminSkill } from '../../../models/admin.model';
import { LucideAngularModule, X, Check, AlertCircle } from 'lucide-angular';

@Component({
  selector: 'app-add-admin-skill-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, LucideAngularModule],
  template: `
    <div class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 transform transition-all">
        <!-- Header -->
        <div class="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 class="text-2xl font-bold text-gray-900">Add New Skill</h2>
          <button (click)="onCancel()" class="text-gray-400 hover:text-gray-600 transition-colors">
            <lucide-icon [name]="'x'" [size]="24"></lucide-icon>
          </button>
        </div>

        <!-- Form -->
        <form [formGroup]="skillForm" (ngSubmit)="onSubmit()" class="p-6 space-y-6">
          <!-- Skill Name -->
          <div class="space-y-2">
            <label for="name" class="block text-sm font-semibold text-gray-700">Skill Name</label>
            <input 
              type="text" 
              id="name" 
              formControlName="name"
              class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              placeholder="Enter skill name"
            >
            <div *ngIf="skillForm.get('name')?.invalid && skillForm.get('name')?.touched" 
                 class="text-sm text-red-500 flex items-center mt-1">
              <lucide-icon [name]="'alert-circle'" [size]="16" class="mr-1"></lucide-icon>
              Skill name is required
            </div>
          </div>

          <!-- Category -->
          <div class="space-y-2">
            <label for="category" class="block text-sm font-semibold text-gray-700">Category</label>
            <select 
              id="category" 
              formControlName="category"
              class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            >
              <option value="">Select a category</option>
              <option *ngFor="let category of skillCategories" [value]="category">
                {{category}}
              </option>
            </select>
            <div *ngIf="skillForm.get('category')?.invalid && skillForm.get('category')?.touched" 
                 class="text-sm text-red-500 flex items-center mt-1">
              <lucide-icon [name]="'alert-circle'" [size]="16" class="mr-1"></lucide-icon>
              Category is required
            </div>
          </div>

          <!-- Description -->
          <div class="space-y-2">
            <label for="description" class="block text-sm font-semibold text-gray-700">Description</label>
            <textarea 
              id="description" 
              formControlName="description"
              rows="4"
              class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
              placeholder="Enter skill description"
            ></textarea>
            <div *ngIf="skillForm.get('description')?.invalid && skillForm.get('description')?.touched" 
                 class="text-sm text-red-500 flex items-center mt-1">
              <lucide-icon [name]="'alert-circle'" [size]="16" class="mr-1"></lucide-icon>
              Description is required
            </div>
          </div>

          <!-- Error Message -->
          <div *ngIf="errorMessage" 
               class="p-4 bg-red-50 border border-red-200 rounded-xl flex items-center text-red-600">
            <lucide-icon [name]="'alert-circle'" [size]="20" class="mr-2"></lucide-icon>
            {{errorMessage}}
          </div>

          <!-- Actions -->
          <div class="flex justify-end gap-4 pt-4">
            <button 
              type="button" 
              (click)="onCancel()"
              class="px-6 py-3 text-sm font-semibold text-gray-700 bg-gray-50 border border-gray-200 rounded-xl hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              [disabled]="!skillForm.valid || isLoading"
              class="px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl hover:from-blue-700 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center"
            >
              <lucide-icon *ngIf="isLoading" [name]="'loader-2'" [size]="16" class="animate-spin mr-2"></lucide-icon>
              <lucide-icon *ngIf="!isLoading" [name]="'check'" [size]="16" class="mr-2"></lucide-icon>
              Add Skill
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class AddAdminSkillModalComponent implements OnInit {
  @Output() close = new EventEmitter<void>();
  @Output() skillAdded = new EventEmitter<AdminSkill>();

  skillForm: FormGroup;
  isLoading = false;
  errorMessage = '';

  skillCategories = [
    'Programming Languages',
    'Frameworks & Libraries',
    'Databases',
    'Cloud Platforms',
    'DevOps & Tools',
    'Mobile Development',
    'Web Development',
    'Data Science & Analytics',
    'Cybersecurity',
    'Project Management',
    'Other'
  ];

  constructor(
    private adminService: AdminService,
    private fb: FormBuilder
  ) {
    this.skillForm = this.fb.group({
      name: ['', Validators.required],
      category: ['', Validators.required],
      description: ['', Validators.required],
      isActive: [true]
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.skillForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';
      
      const skillData = this.skillForm.value;
      
      this.adminService.addAdminSkill(skillData)
        .subscribe({
          next: (response) => {
            this.isLoading = false;
            if (response.success) {
              this.skillAdded.emit(response.data);
              this.onCancel();
            } else {
              this.errorMessage = response.message || 'Failed to add skill';
            }
          },
          error: (error) => {
            this.isLoading = false;
            this.errorMessage = error.error?.message || 'An error occurred while adding the skill';
          }
        });
    }
  }

  onCancel(): void {
    this.close.emit();
  }
}