import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { LucideAngularModule } from 'lucide-angular';
import { AuthService } from '../../../services/auth.service';
import { AppService } from '../../../services/app.service';
import { ApiService } from '../../../services/api.service';
import { AdminSkill } from '../../../models/admin.model';
import { ApiResponse } from '../../../models/api-response.model';
import { FormatEnumPipe } from '../../../pipes/format-enum.pipe';

@Component({
  selector: 'app-requirement-modal',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, LucideAngularModule, FormatEnumPipe],
  templateUrl: './requirement-modal.component.html',
  styleUrls: ['./requirement-modal.component.css']
})
export class RequirementModalComponent implements OnInit {
  @Output() close = new EventEmitter<void>();

  requirementForm: FormGroup;
  availableSkills: AdminSkill[] = [];
  categories = [
    'development',
    'design',
    'project_management',
    'qa_testing',
    'devops',
    'data_science',
    'content_writing',
    'marketing',
    'other'
  ];
  experienceLevels = [
    'junior',
    'mid',
    'senior',
    'expert'
  ];

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private appService: AppService,
    private apiService: ApiService
  ) {
    this.requirementForm = this.fb.group({
      title: ['', Validators.required],
      category: ['', Validators.required],
      skills: this.fb.array([this.fb.control('', Validators.required)]),
      experience: this.fb.group({
        minYears: [1, [Validators.required, Validators.min(0), Validators.max(50)]],
        level: ['', Validators.required]
      }),
      location: ['', Validators.required],
      duration: [6, [Validators.required, Validators.min(1), Validators.max(36)]],
      budget: [50, [Validators.required, Validators.min(1), Validators.max(500)]],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Load available skills from API
    this.apiService.get<ApiResponse<AdminSkill[]>>('/skills/active').subscribe(response => {
      if (response.success && response.data) {
        this.availableSkills = response.data;
        console.log('Requirement Modal: Loaded active skills:', this.availableSkills);
      }
    });
  }

  get skills(): FormArray {
    return this.requirementForm.get('skills') as FormArray;
  }

  get experience(): FormGroup {
    return this.requirementForm.get('experience') as FormGroup;
  }

  addSkill(): void {
    this.skills.push(this.fb.control('', Validators.required));
  }

  removeSkill(index: number): void {
    if (this.skills.length > 1) {
      this.skills.removeAt(index);
    }
  }

  onSubmit(): void {
    if (this.requirementForm.valid) {
      const user = this.authService.currentUser;
      if (!user) return;

      const formValue = this.requirementForm.value;
      const filteredSkills = formValue.skills.filter((skill: string) => skill.trim() !== '');

      if (filteredSkills.length === 0) return;

      // Calculate start date (today) and end date based on duration
      const startDate = new Date();
      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + formValue.duration);

      this.appService.addRequirement({
        title: formValue.title,
        description: formValue.description,
        category: formValue.category,
        skills: filteredSkills,
        experience: {
          minYears: formValue.experience.minYears,
          level: formValue.experience.level
        },
        location: {
          city: formValue.location,
          state: '',
          country: 'USA',
          remote: true
        },
        duration: formValue.duration.toString(),
        budget: {
          hourly: formValue.budget,
          currency: 'USD'
        },
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        clientId: user._id,
        clientName: user.businessInfo?.companyName || 'Unknown Company',
        status: 'open' as const,
        createdBy: user._id
      });

      this.close.emit();
    }
  }

  onClose(): void {
    this.close.emit();
  }
}