import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LucideAngularModule } from 'lucide-angular';
import { Resource } from '../../../models/resource.model';
import { Requirement } from '../../../models/requirement.model';
import { AuthService } from '../../../services/auth.service';
import { AppService } from '../../../services/app.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-apply-resource-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, LucideAngularModule],
  templateUrl: './apply-resource-modal.component.html',
  styleUrls: ['./apply-resource-modal.component.css']
})
export class ApplyResourceModalComponent implements OnInit {
  @Input() requirementId: string = '';
  @Input() resourceId: string = '';
  @Output() close = new EventEmitter<void>();

  currentUser: User | null = null;
  isVendor: boolean = false;
  selectedResources: Resource[] = [];
  notes: string = '';
  requirement: Requirement | null = null;

  constructor(
    private authService: AuthService,
    private appService: AppService
  ) {}

  ngOnInit(): void {
    this.authService.user$.subscribe((user: User | null) => {
      this.currentUser = user;
      this.isVendor = user?.userType === 'vendor';
    });

    if (this.requirementId) {
      this.requirement = this.appService.requirements.find((r: Requirement) => r._id === this.requirementId) || null;
    }
  }

  get availableResources(): Resource[] {
    return this.appService.resources.filter((r: Resource) => 
      r.vendorId === this.currentUser?._id && r.availability.status === 'available'
    );
  }

  isSelected(resourceId: string): boolean {
    return this.selectedResources.some(r => r._id === resourceId);
  }

  toggleSelection(resource: Resource): void {
    const index = this.selectedResources.findIndex(r => r._id === resource._id);
    if (index === -1) {
      this.selectedResources.push(resource);
    } else {
      this.selectedResources.splice(index, 1);
    }
  }

  getFirstThreeSkills(skills: string[]): string[] {
    return skills.slice(0, 3);
  }

  async onSubmit(): Promise<void> {
    if (this.selectedResources.length === 0) return;

    try {
      for (const resource of this.selectedResources) {
        await this.appService.addApplication({
          requirementId: this.requirementId,
          resourceId: resource._id,
          vendorId: this.currentUser!._id,
          clientId: this.requirement!.clientId,
          status: 'pending',
          appliedBy: 'vendor',
          notes: this.notes
        });
      }
      this.close.emit();
    } catch (error) {
      console.error('Error submitting application:', error);
    }
  }

  onClose(): void {
    this.close.emit();
  }
}