import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div class="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
          Sign in to your account
        </h2>
      </div>

      <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div class="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <!-- Demo Accounts -->
          <div class="mb-6 p-4 bg-gray-50 rounded-lg">
            <h3 class="text-sm font-medium text-gray-700 mb-2">Demo Accounts:</h3>
            <div class="space-y-2">
              <div class="text-sm">
                <span class="font-medium">Admin:</span>
                <span class="text-gray-600">admin&#64;talentbridge.com / demo123</span>
              </div>
              <div class="text-sm">
                <span class="font-medium">Vendor:</span>
                <span class="text-gray-600">vendor&#64;techcorp.com / demo123</span>
              </div>
              <div class="text-sm">
                <span class="font-medium">Client:</span>
                <span class="text-gray-600">client&#64;enterprise.com / demo123</span>
              </div>
            </div>
          </div>

          <form class="space-y-6" (ngSubmit)="onSubmit()">
            <div>
              <label for="email" class="block text-sm font-medium text-gray-700">
                Email address
              </label>
              <div class="mt-1">
                <input
                  id="email"
                  name="email"
                  type="email"
                  autocomplete="email"
                  required
                  [(ngModel)]="email"
                  class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <label for="password" class="block text-sm font-medium text-gray-700">
                Password
              </label>
              <div class="mt-1">
                <input
                  id="password"
                  name="password"
                  type="password"
                  autocomplete="current-password"
                  required
                  [(ngModel)]="password"
                  class="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                [disabled]="isLoading"
                class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {{ isLoading ? 'Signing in...' : 'Sign in' }}
              </button>
            </div>

            <div *ngIf="error" class="text-red-600 text-sm mt-2">
              {{ error }}
            </div>
          </form>
        </div>
      </div>
    </div>
  `
})
export class LoginComponent {
  email = '';
  password = '';
  isLoading = false;
  error = '';
  successMessage = '';

  // Demo accounts
  demoAccounts = {
    admin: {
      email: 'admin@talentbridge.com',
      password: 'demo123',
      role: 'Admin',
      company: 'TalentBridge',
      description: 'Full access to all features'
    },
    vendor: {
      email: 'vendor@techcorp.com',
      password: 'demo123',
      role: 'Vendor',
      company: 'TechCorp Solutions',
      description: 'Manage resources and applications'
    },
    client: {
      email: 'client@innovate.com',
      password: 'demo123',
      role: 'Client',
      company: 'Innovate Inc',
      description: 'Post requirements and hire talent'
    }
  };

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  async handleDemoLogin(email: string, password: string): Promise<void> {
    this.email = email;
    this.password = password;
    await this.onSubmit();
  }

  async onSubmit() {
    console.log('LoginComponent: Form submitted');
    if (!this.email || !this.password) {
      console.log('LoginComponent: Email or password missing');
      return;
    }

    this.isLoading = true;
    this.error = '';

    try {
      console.log('LoginComponent: Attempting login');
      const success = await this.authService.login(this.email, this.password);
      console.log('LoginComponent: Login result:', success);

      if (success) {
        console.log('LoginComponent: Login successful, checking user status');
        const user = this.authService.getCurrentUser();
        if (user) {
          // Check if user is approved
          if (user.approvalStatus !== 'approved' && user.userType !== 'admin') {
            this.error = 'Your account is pending approval. Please wait for admin approval.';
            this.authService.logout();
            return;
          }

          // Navigate based on user type
          switch (user.userType) {
            case 'admin':
              this.router.navigate(['/admin-dashboard']);
              break;
            case 'vendor':
              this.router.navigate(['/vendor-dashboard']);
              break;
            case 'client':
              this.router.navigate(['/client-dashboard']);
              break;
            default:
              this.router.navigate(['/']);
          }
        } else {
          this.router.navigate(['/']);
        }
      } else {
        console.log('LoginComponent: Login failed');
        this.error = 'Invalid email or password';
      }
    } catch (error) {
      console.error('LoginComponent: Login error:', error);
      this.error = 'An error occurred during login';
    } finally {
      this.isLoading = false;
    }
  }
}