import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-applications-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div *ngIf="isLoading" class="min-h-screen bg-gray-50 flex items-center justify-center">
      <div class="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
    </div>
    
    <div *ngIf="!isLoading && currentUser" class="min-h-screen bg-gray-50">
      <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <h1 class="text-3xl font-bold text-gray-900">Applications</h1>
        <p class="mt-2 text-gray-600">Welcome, {{ currentUser.firstName }} {{ currentUser.lastName }}!</p>
      </div>
    </div>
  `
})
export class ApplicationsViewComponent implements OnInit {
  currentUser: User | null = null;
  isLoading = false;
  applications: any[] = [];
  userApplications: any[] = [];

  constructor(private authService: AuthService) {}

  ngOnInit() {
    // Subscribe to user changes
    this.authService.user$.subscribe(user => {
      console.log('Applications View: User state changed:', user);
      this.currentUser = user;
      
      if (user) {
        console.log('Applications View: User type:', user.userType);
        this.loadApplications();
      } else {
        this.userApplications = [];
      }
    });

    // Subscribe to loading state
    this.authService.isLoading$.subscribe(isLoading => {
      this.isLoading = isLoading;
    });
  }

  private loadApplications(): void {
    if (!this.currentUser) {
      this.userApplications = [];
      return;
    }

    const userId = this.currentUser._id;
    const userType = this.currentUser.userType;

    this.userApplications = this.applications.filter(app => 
      userType === 'vendor' ? app.vendorId === userId : app.clientId === userId
    );
  }
}