import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LucideAngularModule } from 'lucide-angular';
import { LayoutComponent } from '../layout/layout.component';
import { AddAdminSkillModalComponent } from '../modals/add-admin-skill-modal/add-admin-skill-modal.component';
import { AuthService } from '../../services/auth.service';
import { AdminService } from '../../services/admin.service';
import { AppService } from '../../services/app.service';
import { VendorManagementService } from '../../services/vendor-management.service';
import { AdminSkill, PlatformStats, TransactionData, UserApproval, SkillApproval } from '../../models/admin.model';
import { VendorSkill } from '../../models/vendor-skill.model';
import { User } from '../../models/user.model';
import { Resource } from '../../models/resource.model';
import { Requirement } from '../../models/requirement.model';
import { Application } from '../../models/application.model';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable, Subscription } from 'rxjs';

interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  pagination?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

interface NavigationTab {
  id: 'overview' | 'user-approvals' | 'skill-approvals' | 'skills' | 'transactions' | 'users';
  label: string;
  icon: string;
  badge?: number;
}

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule,
    LucideAngularModule, 
    LayoutComponent,
    AddAdminSkillModalComponent
  ],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit, OnDestroy {
  currentUser: User | null = null;
  isLoading = false;
  activeTab: 'overview' | 'user-approvals' | 'skill-approvals' | 'skills' | 'transactions' | 'users' = 'overview';
  
  // Data
  userApprovals: UserApproval[] = [];
  skillApprovals: SkillApproval[] = [];
  adminSkills: AdminSkill[] = [];
  platformStats: PlatformStats = {
    totalUsers: 0,
    totalVendors: 0,
    totalClients: 0,
    totalResources: 0,
    totalRequirements: 0,
    totalApplications: 0,
    pendingApprovals: 0,
    activeSkills: 0,
    monthlyGrowth: {
      users: 0,
      applications: 0,
      placements: 0
    }
  };
  transactions: TransactionData[] = [];
  allUsers: User[] = [];
  allResources: Resource[] = [];
  allRequirements: Requirement[] = [];
  allApplications: Application[] = [];

  // Modals
  showAddSkillModal = false;
  showApprovalModal = false;
  showRejectModal = false;
  showSkillApprovalModal = false;
  showSkillRejectModal = false;
  selectedEntity: User | null = null;
  selectedVendorSkill: VendorSkill | null = null;
  rejectNotes = '';
  skillRejectNotes = '';

  // Filters
  approvalFilter = 'all';
  transactionFilter = 'all';
  skillFilter = 'all';
  skillApprovalFilter = 'all';

  // Pagination
  currentPage = 1;
  totalPages = 1;
  itemsPerPage = 10;
  totalItems = 0;

  // Loading states
  loadingStates = {
    userApprovals: false,
    skillApprovals: false,
    skills: false,
    stats: false,
    transactions: false,
    users: false
  };

  // Navigation
  navigationTabs: NavigationTab[] = [
    { id: 'overview', label: 'Overview', icon: 'home' },
    { id: 'user-approvals', label: 'User Approvals', icon: 'user-check', badge: 0 },
    { id: 'skill-approvals', label: 'Skill Approvals', icon: 'check-circle', badge: 0 },
    { id: 'skills', label: 'Skills', icon: 'list' },
    { id: 'transactions', label: 'Transactions', icon: 'credit-card' },
    { id: 'users', label: 'Users', icon: 'users' }
  ];

  private subscriptions: Subscription[] = [];

  constructor(
    private authService: AuthService,
    private adminService: AdminService,
    private appService: AppService,
    private vendorManagementService: VendorManagementService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    // Subscribe to user changes
    this.authService.user$.subscribe(user => {
      console.log('Admin Dashboard: User state changed:', user);
      this.currentUser = user;
      
      if (user) {
        console.log('Admin Dashboard: User type:', user.userType);
        
        // Check if user is admin
        if (user.userType !== 'admin') {
          console.log('Admin Dashboard: User is not admin, redirecting...');
          this.router.navigate(['/']);
          return;
        }
        
        // Load admin data
        this.loadDashboardData();
      } else {
        console.log('Admin Dashboard: No user logged in, redirecting...');
        this.router.navigate(['/login']);
      }
    });

    // Subscribe to loading state
    this.authService.isLoading$.subscribe(isLoading => {
      this.isLoading = isLoading;
    });

    this.setupSubscriptions();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  private setupSubscriptions(): void {
    // Subscribe to user approvals
    this.subscriptions.push(
      this.adminService.userApprovals$.subscribe(response => {
        if (response.success) {
          this.userApprovals = response.data;
          this.totalPages = response.pagination?.totalPages || 1;
        }
      })
    );

    // Subscribe to skill approvals
    this.subscriptions.push(
      this.adminService.skillApprovals$.subscribe(response => {
        if (response.success) {
          this.skillApprovals = response.data;
          this.totalPages = response.pagination?.totalPages || 1;
        }
      })
    );

    // Subscribe to admin skills
    this.subscriptions.push(
      this.adminService.adminSkills$.subscribe(skills => {
        this.adminSkills = skills;
      })
    );

    // Subscribe to platform stats
    this.subscriptions.push(
      this.adminService.platformStats$.subscribe(stats => {
        this.platformStats = stats;
        console.log('Platform stats updated:', stats); // Debug log
      })
    );

    // Subscribe to transactions
    this.subscriptions.push(
      this.adminService.transactions$.subscribe(transactions => {
        this.transactions = transactions;
      })
    );
  }

  private loadDashboardData(): void {
    this.isLoading = true;
    this.loadUserApprovals();
    this.loadSkillApprovals();
    this.loadAdminSkills();
    this.loadPlatformStats();
    this.loadTransactions();
    this.loadUsers();
  }

  private loadUserApprovals(): void {
    this.loadingStates.userApprovals = true;
    const sub = this.adminService.getUserApprovals(this.currentPage, this.itemsPerPage).subscribe({
      next: (response) => {
        this.userApprovals = response.data;
        if (response.pagination) {
          this.totalItems = response.pagination.total;
          this.totalPages = response.pagination.totalPages;
        }
        this.navigationTabs.find(tab => tab.id === 'user-approvals')!.badge = 
          this.userApprovals.filter(a => a.approvalStatus === 'pending').length;
        this.loadingStates.userApprovals = false;
      },
      error: (error) => {
        console.error('Error loading user approvals:', error);
        this.loadingStates.userApprovals = false;
        this.toastr.error('Failed to load user approvals');
      }
    });
    this.subscriptions.push(sub);
  }

  private loadSkillApprovals(): void {
    this.loadingStates.skillApprovals = true;
    const sub = this.adminService.getSkillApprovals(this.currentPage, this.itemsPerPage).subscribe({
      next: (response) => {
        this.skillApprovals = response.data;
        if (response.pagination) {
          this.totalItems = response.pagination.total;
          this.totalPages = response.pagination.totalPages;
        }
        this.navigationTabs.find(tab => tab.id === 'skill-approvals')!.badge = 
          this.skillApprovals.filter(a => a.status === 'pending').length;
        this.loadingStates.skillApprovals = false;
      },
      error: (error) => {
        console.error('Error loading skill approvals:', error);
        this.loadingStates.skillApprovals = false;
        this.toastr.error('Failed to load skill approvals');
      }
    });
    this.subscriptions.push(sub);
  }

  private loadAdminSkills(): void {
    this.loadingStates.skills = true;
    const sub = this.adminService.getAdminSkills().subscribe({
      next: (response) => {
        console.log('Admin Dashboard: Skills response:', response);
        if (response.success) {
          this.adminSkills = response.data;
          if (response.pagination) {
            this.totalItems = response.pagination.total;
            this.totalPages = response.pagination.totalPages;
          }
        } else {
          console.error('Admin Dashboard: Failed to load skills:', response.message);
          this.toastr.error(response.message || 'Failed to load skills');
        }
        this.loadingStates.skills = false;
      },
      error: (error) => {
        console.error('Error loading admin skills:', error);
        this.loadingStates.skills = false;
        this.toastr.error('Failed to load admin skills');
      }
    });
    this.subscriptions.push(sub);
  }

  private loadPlatformStats(): void {
    this.loadingStates.stats = true;
    const sub = this.adminService.getPlatformStats().subscribe({
      next: (stats) => {
        this.platformStats = stats;
        this.loadingStates.stats = false;
      },
      error: (error) => {
        console.error('Error loading platform stats:', error);
        this.loadingStates.stats = false;
        this.toastr.error('Failed to load platform stats');
      }
    });
    this.subscriptions.push(sub);
  }

  private loadTransactions(): void {
    this.loadingStates.transactions = true;
    const sub = this.adminService.getTransactions().subscribe({
      next: (transactions) => {
        this.transactions = transactions;
        this.loadingStates.transactions = false;
      },
      error: (error) => {
        console.error('Error loading transactions:', error);
        this.loadingStates.transactions = false;
        this.toastr.error('Failed to load transactions');
      }
    });
    this.subscriptions.push(sub);
  }

  private loadUsers(): void {
    this.loadingStates.users = true;
    const sub = this.adminService.getUsers(this.currentPage, this.itemsPerPage).subscribe({
      next: (response) => {
        console.log('Admin Dashboard: Users response:', response);
        if (response.success) {
          this.allUsers = response.data;
          if (response.pagination) {
            this.totalItems = response.pagination.total;
            this.totalPages = response.pagination.totalPages;
          }
        } else {
          console.error('Admin Dashboard: Failed to load users:', response.message);
          this.toastr.error(response.message || 'Failed to load users');
        }
        this.loadingStates.users = false;
      },
      error: (error) => {
        console.error('Admin Dashboard: Error loading users:', error);
        this.loadingStates.users = false;
        this.toastr.error('Failed to load users');
      }
    });
    this.subscriptions.push(sub);
  }

  setActiveTab(tab: 'overview' | 'user-approvals' | 'skill-approvals' | 'skills' | 'transactions' | 'users'): void {
    this.activeTab = tab;
    this.currentPage = 1;
    this.loadTabData();
  }

  loadTabData(): void {
    switch (this.activeTab) {
      case 'user-approvals':
        this.loadUserApprovals();
        break;
      case 'skill-approvals':
        this.loadSkillApprovals();
        break;
      case 'skills':
        this.loadAdminSkills();
        break;
      case 'transactions':
        this.loadTransactions();
        break;
      case 'users':
        this.loadUsers();
        break;
    }
  }

  // Approval Management
  openApprovalModal(entity: User): void {
    this.selectedEntity = entity;
    this.showApprovalModal = true;
  }

  closeApprovalModal(): void {
    this.showApprovalModal = false;
    this.selectedEntity = null;
  }

  openRejectModal(entity: User): void {
    this.selectedEntity = entity;
    this.showRejectModal = true;
    this.rejectNotes = '';
  }

  closeRejectModal(): void {
    this.showRejectModal = false;
    this.selectedEntity = null;
    this.rejectNotes = '';
  }

  approveUser(userId: string): void {
    const sub = this.adminService.approveUser(userId).subscribe({
      next: () => {
        this.toastr.success('User approved successfully');
        this.loadUserApprovals();
        this.loadPlatformStats();
      },
      error: (error) => {
        console.error('Error approving user:', error);
        this.toastr.error('Failed to approve user');
      }
    });
    this.subscriptions.push(sub);
  }

  rejectUser(userId: string, notes: string): void {
    const sub = this.adminService.rejectUser(userId, notes).subscribe({
      next: () => {
        this.toastr.success('User rejected successfully');
        this.loadUserApprovals();
        this.loadPlatformStats();
      },
      error: (error) => {
        console.error('Error rejecting user:', error);
        this.toastr.error('Failed to reject user');
      }
    });
    this.subscriptions.push(sub);
  }

  // Vendor Skill Approval Management
  openSkillApprovalModal(skill: VendorSkill): void {
    this.selectedVendorSkill = skill;
    this.showSkillApprovalModal = true;
  }

  closeSkillApprovalModal(): void {
    this.showSkillApprovalModal = false;
    this.selectedVendorSkill = null;
  }

  openSkillRejectModal(skill: VendorSkill): void {
    this.selectedVendorSkill = skill;
    this.showSkillRejectModal = true;
    this.skillRejectNotes = '';
  }

  closeSkillRejectModal(): void {
    this.showSkillRejectModal = false;
    this.selectedVendorSkill = null;
    this.skillRejectNotes = '';
  }

  approveSkill(skillId: string): void {
    const sub = this.adminService.approveSkill(skillId).subscribe({
      next: () => {
        this.toastr.success('Skill approved successfully');
        this.loadSkillApprovals();
        this.loadPlatformStats();
      },
      error: (error) => {
        console.error('Error approving skill:', error);
        this.toastr.error('Failed to approve skill');
      }
    });
    this.subscriptions.push(sub);
  }

  rejectSkill(skillId: string, notes: string): void {
    const sub = this.adminService.rejectSkill(skillId, notes).subscribe({
      next: () => {
        this.toastr.success('Skill rejected successfully');
        this.loadSkillApprovals();
        this.loadPlatformStats();
      },
      error: (error) => {
        console.error('Error rejecting skill:', error);
        this.toastr.error('Failed to reject skill');
      }
    });
    this.subscriptions.push(sub);
  }

  // Skill Management
  async toggleSkillStatus(skill: AdminSkill): Promise<void> {
    try {
      const updatedSkill = await this.adminService.updateSkill(skill.id, {
        ...skill,
        isActive: !skill.isActive
      }).toPromise();
      this.toastr.success('Skill status updated successfully');
      this.loadAdminSkills();
    } catch (error) {
      console.error('Error updating skill status:', error);
      this.toastr.error('Failed to update skill status');
    }
  }

  async deleteSkill(skillId: string): Promise<void> {
    try {
      await this.adminService.deleteSkill(skillId).toPromise();
      this.toastr.success('Skill deleted successfully');
      this.loadAdminSkills();
    } catch (error) {
      console.error('Error deleting skill:', error);
      this.toastr.error('Failed to delete skill');
    }
  }

  // Utility Methods
  getApprovalTypeIcon(type: string): string {
    const icons: { [key: string]: string } = {
      vendor: 'package',
      client: 'target',
      skill: 'briefcase'
    };
    return icons[type] || 'help-circle';
  }

  getApprovalTypeColor(type: string): string {
    const colors: { [key: string]: string } = {
      vendor: 'text-blue-600 bg-blue-100',
      client: 'text-purple-600 bg-purple-100',
      skill: 'text-green-600 bg-green-100'
    };
    return colors[type] || 'text-gray-600 bg-gray-100';
  }

  getStatusColor(status: string): string {
    const colors: { [key: string]: string } = {
      pending: 'text-yellow-800 bg-yellow-100',
      approved: 'text-green-800 bg-green-100',
      rejected: 'text-red-800 bg-red-100'
    };
    return colors[status] || 'text-gray-800 bg-gray-100';
  }

  getTransactionTypeIcon(type: string): string {
    const icons: { [key: string]: string } = {
      application: 'trending-up',
      requirement: 'briefcase',
      resource: 'users',
      user_registration: 'user-plus'
    };
    return icons[type] || 'activity';
  }

  formatTransactionType(type: string): string {
    return type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  }

  getFilteredApprovals(): UserApproval[] {
    return this.userApprovals.filter(approval => {
      if (this.approvalFilter === 'all') return true;
      return approval.approvalStatus === this.approvalFilter;
    });
  }

  getFilteredTransactions(): TransactionData[] {
    if (this.transactionFilter === 'all') {
      return this.transactions;
    }
    return this.transactions.filter(transaction => transaction.type === this.transactionFilter);
  }

  getFilteredSkills(): AdminSkill[] {
    if (this.skillFilter === 'all') {
      return this.adminSkills;
    }
    return this.adminSkills.filter(skill => skill.category === this.skillFilter);
  }

  getFilteredVendorSkills(): VendorSkill[] {
    if (this.skillApprovalFilter === 'all') {
      return this.skillApprovals.map(a => a.skill);
    }
    return this.skillApprovals.filter(a => a.status === this.skillApprovalFilter).map(a => a.skill);
  }

  getPaginatedItems<T>(items: T[]): T[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    return items.slice(startIndex, startIndex + this.itemsPerPage);
  }

  getTotalPages<T>(items: T[]): number {
    return Math.ceil(items.length / this.itemsPerPage);
  }

  changePage(page: number): void {
    this.currentPage = page;
  }

  getSkillCategories(): Observable<string[]> {
    return this.adminService.getSkillCategories();
  }

  getProficiencyClass(level: string): string {
    switch (level) {
      case 'expert':
        return 'bg-purple-100 text-purple-800';
      case 'advanced':
        return 'bg-blue-100 text-blue-800';
      case 'intermediate':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  getVendorName(vendorId: string): string {
    const user = this.allUsers.find(u => u._id === vendorId);
    if (!user) return 'Unknown Vendor';
    return user.businessInfo?.companyName || 'Unknown Vendor';
  }

  // Helper methods for user management
  getUserResourceCount(user: User): number {
    return this.allResources.filter(r => r.vendorId === user._id).length;
  }

  getUserRequirementCount(user: User): number {
    return this.allRequirements.filter(r => r.clientId === user._id).length;
  }

  getUserVendorApplicationCount(user: User): number {
    return this.allApplications.filter(a => a.vendorId === user._id).length;
  }

  getUserClientApplicationCount(user: User): number {
    return this.allApplications.filter(a => a.clientId === user._id).length;
  }

  // Stats calculations
  getGrowthPercentage(current: number, previous: number): number {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
  }

  isGrowthPositive(growth: number): boolean {
    return growth > 0;
  }

  // Check if reject notes are valid
  isRejectNotesValid(): boolean {
    return this.rejectNotes.trim().length > 0;
  }

  isSkillRejectNotesValid(): boolean {
    return this.skillRejectNotes.trim().length > 0;
  }

  // Helper method to get pending vendor skills for template
  getPendingVendorSkills(): VendorSkill[] {
    return this.skillApprovals.map(a => a.skill).slice(0, 5);
  }

  // Helper method to check if pending vendor skills exist
  hasPendingVendorSkills(): boolean {
    return this.skillApprovals.length > 0;
  }

  getUserTypeColor(userType: string): string {
    switch (userType) {
      case 'vendor':
        return 'bg-blue-100 text-blue-600';
      case 'client':
        return 'bg-green-100 text-green-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  }

  getUserTypeIcon(userType: string): string {
    switch (userType) {
      case 'vendor':
        return 'store';
      case 'client':
        return 'user';
      default:
        return 'user';
    }
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  onFilterChange(): void {
    this.currentPage = 1;
    this.loadTabData();
  }

  editSkill(skill: AdminSkill): void {
    // TODO: Implement skill editing
    console.log('Edit skill:', skill);
  }

  editUser(user: User): void {
    // TODO: Implement user editing
    console.log('Edit user:', user);
  }

  toggleUserStatus(user: User): void {
    // TODO: Implement user status toggle
    console.log('Toggle user status:', user);
  }

  // Computed properties for template bindings
  get pendingUserApprovalsCount(): number {
    return this.userApprovals.filter(a => a.approvalStatus === 'pending').length;
  }

  get pendingSkillApprovalsCount(): number {
    return this.skillApprovals.filter(a => a.status === 'pending').length;
  }

  get filteredUserApprovals(): UserApproval[] {
    if (this.approvalFilter === 'all') return this.userApprovals;
    return this.userApprovals.filter(a => a.approvalStatus === this.approvalFilter);
  }

  get filteredSkillApprovals(): SkillApproval[] {
    if (this.skillApprovalFilter === 'all') return this.skillApprovals;
    return this.skillApprovals.filter(a => a.status === this.skillApprovalFilter);
  }

  onSkillAdded(newSkill: AdminSkill): void {
    // Add the new skill to the list
    this.adminSkills = [...this.adminSkills, newSkill];
    
    // Update platform stats
    this.platformStats = {
      ...this.platformStats,
      activeSkills: this.platformStats.activeSkills + 1
    };
    
    // Show success message
    this.toastr.success('Skill added successfully');
  }
}